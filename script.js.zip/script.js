document.getElementById('signup-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const nom = document.getElementById('nom').value;
    const prenom = document.getElementById('prenom').value;

    // Message personnalisé
    const message = `${prenom} ${nom}, Huguesshop vous souhaite un très Joyeux Noël !`;
    document.getElementById('greeting').textContent = message;

    // Masquer le formulaire et afficher le message
    document.getElementById('form-container').classList.add('hidden');
    document.getElementById('message-container').classList.remove('hidden');

    // Jouer la musique
    const music = document.getElementById('background-music');
    music.play();
});